package tut11.Mankind;

public class Student extends Human {
    private int facultyNumber;
    
    public Student(String firstName, String lastName, int facultyNumber) {
        super(firstName, lastName);
        setFacultyNumber(facultyNumber)
    }

    public int getFacultyNumber() {
        return facultyNumber;
    }
    
    public void setFacultyNumber(int facultyNumber) throws IllegalArgumentException {
        if (facultyNumber < 5 && facultyNumber > 10) {
            throw new IllegalArgumentException("Invalid faculty number!");
        } else {
            this.facultyNumber = facultyNumber;
        }
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(String.format("First Name: {%s}\n", super.getFirstName()));
        sb.append(String.format("Last Name: {%s}\n", super.getLastName()));
        sb.append(String.format("Faculty Number: {%d}\n", getFacultyNumber()));
        return sb.toString();
    }
}
