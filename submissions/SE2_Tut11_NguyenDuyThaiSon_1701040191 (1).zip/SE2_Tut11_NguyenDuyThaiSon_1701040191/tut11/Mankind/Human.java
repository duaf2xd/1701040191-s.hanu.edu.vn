package tut11.Mankind;

public class Human {
    private String firstName;
    protected String lastName;
    
    public Human(String firstName, String lastName) {
        setFirstName(firstName);
        setLastName(lastName);
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) throws IllegalArgumentException {
        char first = firstName.charAt(0);
        if (!Character.isUpperCase(first)) {
            throw new IllegalArgumentException("First name is not properly capitalized: " + firstName);
        } else if(firstName.length() < 4) {
            throw new IllegalArgumentException("First name is too short: " + firstName);
        }
        else {
            this.firstName = firstName;
        }
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) throws IllegalArgumentException {
        char first = lastName.charAt(0);
        if (!Character.isUpperCase(first)) {
            throw new IllegalArgumentException("Last name is not properly capitalized: " + lastName);
        } else {
            this.lastName = lastName;
        }
    }
}
