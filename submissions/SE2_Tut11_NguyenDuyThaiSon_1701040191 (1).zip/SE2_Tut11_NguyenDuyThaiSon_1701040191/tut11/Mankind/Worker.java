package tut11.Mankind;

public class Worker extends Human {
    private double weekSalary;
    private int workingHours;
    
    public Worker(String firstName, String lastName, double weekSalary, int workingHours) {
        super(firstName, lastName);
        setWeekSalary(weekSalary);
        setWorkingHours(workingHours);
    }
    
    @Override
    public void setLastName(String lastName) {
        if (lastName.length() < 3) {
            throw new IllegalArgumentException("Last name is too short: " + lastName);
        } else {
            this.lastName = lastName;
        }
    }
    
    public double getWeekSalary() {
        return weekSalary;
    }
    
    public void setWeekSalary(double weekSalary) throws IllegalArgumentException {
        if (weekSalary <= 10) {
            throw new IllegalArgumentException("Week salary is too low: " + weekSalary);
        } else {
            this.weekSalary = weekSalary;
        }
    }
    
    public int getWorkingHours() {
        return workingHours;
    }
    
    public void setWorkingHours(int workingHours) throws IllegalArgumentException {
        if (workingHours < 1 && workingHours > 12) {
            throw new IllegalArgumentException("Invalid working hours: " + workingHours);
        } else {
            this.workingHours = workingHours;
        }
    }
    
    public double getSalaryPerHour() {
        double result = this.weekSalary/7/24;
         return result;
    }
    
    @Override
    public String toString() {
        final StringBuilder sb = new StringBuilder();
        sb.append(String.format("First Name: {%s}\n", super.getFirstName()));
        sb.append(String.format("Last Name: {%s}\n", super.getLastName()));
        sb.append(String.format("Week Salary: {%.2f}\n", getWeekSalary()));
        sb.append(String.format("Hours per day: {%d}\n", getWorkingHours()));
        sb.append(String.format("Salary per hour: {%.2f}\n", getSalaryPerHour()));
        return sb.toString();
    }
}
