package demo.model;


import javax.xml.bind.annotation.XmlRootElement;

@XmlRootElement
public class Teacher {
	private int TeacherID;
	private String TeacherName;
	private String TeacherMobile;
	
	public Teacher() {
		super();
	}
	public Teacher(int teacherID, String teacherName, String teacherMobile) {
		super();
		TeacherID = teacherID;
		TeacherName = teacherName;
		TeacherMobile = teacherMobile;
	}

	public int getTeacherID() {
		return TeacherID;
	}
	public void setTeacherID(int teacherID) {
		TeacherID = teacherID;
	}
	public String getTeacherName() {
		return TeacherName;
	}
	public void setTeacherName(String teacherName) {
		TeacherName = teacherName;
	}
	public String getTeacherMobile() {
		return TeacherMobile;
	}
	public void setTeacherMobile(String teacherMobile) {
		TeacherMobile = teacherMobile;
	}
	
	
}
