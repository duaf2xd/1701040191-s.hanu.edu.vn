package demo.service;

import java.util.ArrayList;
import java.util.List;

import demo.model.Teacher;

public class TeacherService {
	public List<Teacher> getAllTeachers() {
		Teacher s1 = new Teacher (1,"Hoang Minh", "0912264248");
		Teacher s2 = new Teacher (2,"Khanh Ngoc", "0925472686");
		List<Teacher> list6 = new ArrayList<Teacher>();
		list6.add(s1);
		list6.add(s2);
		return list6;
	}
}

